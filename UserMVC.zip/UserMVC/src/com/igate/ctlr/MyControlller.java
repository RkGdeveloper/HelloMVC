package com.igate.ctlr;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.igate.bean.Login;

@Controller
@RequestMapping(value="home")
public class MyControlller {

	
	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		
		String mydate = new Date().toString();
		return new ModelAndView("pages/Hello","today",mydate);
	}
	
	
	@RequestMapping("/showlogin")
	public String prepeareLogin(Model model){
		
		Login l = new Login();
		l.setUserName("Govind");
		model.addAttribute("login",l);
		return "pages/Login";
		
	}
	
	@RequestMapping("/checkLogin")
	public String checkCredentials(@ModelAttribute(value="login") @Valid Login login,BindingResult result,Model model){
		//client side validation
				if(result.hasErrors())
				{
				//	model.addAttribute("login",new Login());
					return "pages/login";
				}
				
				if(login.getUserName().equals("igate") && login.getPassword().equals("igate"))
				{
					model.addAttribute("login",login);
					model.addAttribute("msg", "Successfully Logged in");
				    return "pages/success";
				}
				else
					return "pages/error";
	}
}
