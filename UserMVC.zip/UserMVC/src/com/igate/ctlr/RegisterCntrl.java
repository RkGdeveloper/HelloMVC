package com.igate.ctlr;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.igate.bean.User;

@Controller
@RequestMapping("registerCtrl")
public class RegisterCntrl {
	
	

	ArrayList<Integer> deptList;
	ArrayList<String> qualiList;
	
	
	@RequestMapping(value="showRegister")
	public String prepareRegister(Model model)
	{
		
		deptList = new ArrayList<Integer>();
		deptList.add(1001);
		deptList.add(1002);
		deptList.add(1003);
		deptList.add(1004);
		
		/*cityList =new ArrayList<String>();
		
		cityList.add("Mumbai");
		cityList.add("Bangalore");
		cityList.add("Chennai");
		cityList.add("Delhi");*/
		
		
		
		qualiList =new ArrayList<String>();
		
		qualiList.add("BE");
		qualiList.add("BTech");
		qualiList.add("Diploma");
		qualiList.add("PHD");
		
		model.addAttribute("deptList",deptList);
		model.addAttribute("qualiList",qualiList);
		
		
		model.addAttribute("user",new User());
	    return "pages/register";	
	}
	
	@RequestMapping(value="checkRegister")
	public String checkRegister(User user ,Model model)
	{
          model.addAttribute("user",user);  		  
	  	  return "pages/registerSuccess";	

	}
}
