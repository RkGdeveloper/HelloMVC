package com.igate.bean;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Login {

	
	private String userName;
	private String password;
	
	
	@NotEmpty(message = "Username is Required")
	@Size(min = 4,message = "min 6 character")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@NotEmpty(message = "Password is Required")
	@Size(min = 8,message = "min 8 character")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
